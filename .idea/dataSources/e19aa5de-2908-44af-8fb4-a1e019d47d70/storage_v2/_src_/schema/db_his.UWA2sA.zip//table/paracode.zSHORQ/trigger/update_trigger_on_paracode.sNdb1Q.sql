create definer = root@localhost trigger update_trigger_on_paracode
    after update
    on paracode
    for each row
BEGIN
IF (new.code = '003') THEN
update category set type=new.parameter_values,name=new.parameter_name where type=new.parameter_values;
END IF;
END;

